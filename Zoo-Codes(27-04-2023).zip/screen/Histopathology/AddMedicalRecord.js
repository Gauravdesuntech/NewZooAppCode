import react from "react";
import {
    StyleSheet,
    TouchableOpacity,
    Text,
    View,
} from "react-native";
import {
    widthPercentageToDP as wp,
    heightPercentageToDP as hp,
} from "react-native-responsive-screen";
import CustomForm from "../../components/CustomForm";
import AnimalListCard from "../../components/AnimalListCard";
import AddMedicalRecordCard from "./AddMedicalRecordCard";
import Card from "../../components/CustomCard";

const MedicalRecord = () => {
    return (
        <>
            <CustomForm
                header={true}
                title={"Add Medical Record"}
            // onPress={onSubmit}
            // marginBottom={50}
            >
                <View>
                    <AddMedicalRecordCard
                       title={"Select Section,Encloure"}
                      checkbox={true}
                      name={"check"}
                    />
                </View>
                <View>
                    <AddMedicalRecordCard
                       title={"Case Type"}
                      checkbox={true}
                      name={"check"}
                    />
                </View>
                <View>
                    <AddMedicalRecordCard
                       title={"Complaints"}
                      checkbox={true}
                      name={"check"}
                    />
                </View>
                <View>
                    <AddMedicalRecordCard
                       title={"Daignosis"}
                      checkbox={true}
                      name={"check"}
                    />
                </View>
                <View>
                    <AddMedicalRecordCard
                       title={"Lab Test Request"}
                      checkbox={true}
                      name={"check"}
                    />
                </View>
                <View>
                    <AddMedicalRecordCard
                       title={"Prescription"}
                      checkbox={true}
                      name={"check"}
                    />
                </View>
                <View>
                    <AddMedicalRecordCard
                       title={"Follow Up Date"}
                      checkbox={true}
                      name={"check"}
                    />
                </View>
                <View>
                    <AddMedicalRecordCard
                       title={"Advice"}
                      checkbox={true}
                      name={"check"}
                    />
                </View>
                <View>
                    <AddMedicalRecordCard
                       title={"Health Status"}
                      checkbox={true}
                      name={"check"}
                    />
                </View>
                <View>
                    <AddMedicalRecordCard
                       title={"Notes"}
                      checkbox={true}
                      name={"check"}
                    />
                </View>

            </CustomForm>
        </>
    )
}
export default MedicalRecord;