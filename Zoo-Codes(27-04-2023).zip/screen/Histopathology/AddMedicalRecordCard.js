
import React from 'react';
import { View, Text, StyleSheet, Image, ScrollView, TouchableWithoutFeedback} from 'react-native';
import { AntDesign, MaterialCommunityIcons } from '@expo/vector-icons';
import Colors from '../../configs/Colors';
import {
    widthPercentageToDP as wp,
    heightPercentageToDP as hp,
} from "react-native-responsive-screen";

const AddMedicalRecordCard = ({ UserEnclosureName, title, subtitle, onPress, checkbox ,...props}) => {

    // console.log('THESE ARE TEH RECEIVED SEX DATA: ', tags);

    return (
        <TouchableWithoutFeedback onPress={onPress}>

            <View style={styles.cardContainer}>
                {checkbox ?
                    <View style={styles.checkbox}>
                        <MaterialCommunityIcons
                            name={props.name}
                            size={wp(7)}
                        />
                    </View> : null}
                    <View style={styles.middleSection}>
                        {
                            title ? <View style={{ display: "flex", flexDirection: "row" }}>
                                <Text style={styles.title}>{title}</Text>
                                {/* {chips} */}
                            </View> : null}

                        {/* {
                            subtitle ?
                                <Text style={title ? styles.subtitle : styles.title}>{subtitle}</Text>
                                : null} */}

                    </View>

                    <View style={styles.enclosure}>
                        <Text style={styles.enclosureName}>{UserEnclosureName}</Text>
                    </View>
                <View
                    style={{
                        marginLeft: wp(4),
                        marginVertical: wp(6.5),
                        marginTop: hp(2)
                    }}
                >
                    <AntDesign name="right" size={wp(7)} color="black" />
                </View>
            </View>
        </TouchableWithoutFeedback>
    );
};

const styles = StyleSheet.create({
    enclosureName: {

        margin: '2%',
        paddingLeft: '3%',
        fontSize: 13,

    },
    cardContainer: {
        borderWidth:1,
        borderColor:"#D9D9D9",
        backgroundColor: "#F2FFF8",
        borderRadius: wp("2%"),
        marginVertical: wp("2%"),

        elevation: 2, // for shadow on Android
        shadowColor: '#000', // for shadow on iOS
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.2,
        shadowRadius: 2,
        flexDirection: 'row',
        paddingHorizontal: 10,
        paddingVertical: 8
    },

    middleSection: {
        width: "70%",
        paddingLeft: wp(4),
        justifyContent: 'center',

    },
    title: {
        fontSize: wp(4.8),
        fontWeight: '400',
        marginBottom: 4,
        color: Colors.subtitle,
        // backgroundColor:'yellow',
        width: '100%'
    },
    subtitle: {
        fontSize: 13,
        color: Colors.subtitle,
        fontWeight: '400',
        width: '100%',
        // backgroundColor:'red'

    },

    checkbox: {
        backgroundColor: "#D9D9D9",
        marginTop: hp(1.5),
        height: hp(5),
        padding: wp(1.8),
        alignItems: "center",
        borderRadius: wp(5),
    },
});

export default AddMedicalRecordCard;